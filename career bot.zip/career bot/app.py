from flask import Flask, render_template, request, redirect, url_for
import random

app = Flask(__name__)

# Quiz data
quizzes = {
    "Beginner": [
        {"question": "Which device connects multiple networks together?",
         "options": ["A. Switch", "B. Router", "C. Hub", "D. Repeater"], "answer": "B"},
        {"question": "Which layer does the IP protocol operate at?",
         "options": ["A. Data Link", "B. Transport", "C. Network", "D. Session"], "answer": "C"}
    ],
    "Intermediate": [
        {"question": "What is the subnet mask for a /24 network?",
         "options": ["A. 255.255.0.0", "B. 255.255.255.0", "C. 255.0.0.0", "D. 255.255.255.255"], "answer": "B"},
        {"question": "Which protocol uses three-way handshake?",
         "options": ["A. UDP", "B. TCP", "C. ICMP", "D. ARP"], "answer": "B"}
    ],
    "Expert": [
        {"question": "Which command displays the ARP table in Windows?",
         "options": ["A. netstat", "B. ipconfig", "C. arp -a", "D. tracert"], "answer": "C"},
        {"question": "Which protocol is used for securely managing network devices?",
         "options": ["A. SNMPv1", "B. FTP", "C. Telnet", "D. SSH"], "answer": "D"}
    ]
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/certification_resources')
def certification_resources():
    return render_template('certification_resources.html')

@app.route('/career_opportunities')
def career_opportunities():
    return render_template('career_opportunities.html')

@app.route('/join_communities')
def join_communities():
    return render_template('join_communities.html')

@app.route('/select_quiz_level', methods=['GET', 'POST'])
def select_quiz_level():
    if request.method == 'POST':
        level = request.form.get('level')
        return redirect(url_for('start_quiz', level=level))
    return render_template('select_quiz_level.html')

@app.route('/start_quiz/<level>', methods=['GET', 'POST'])
def start_quiz(level):
    quiz_data = quizzes.get(level, [])
    score = 0
    total_questions = len(quiz_data)
    if request.method == 'POST':
        selected_answer = request.form.get('answer')
        question_index = int(request.form.get('question_index'))
        correct_answer = quiz_data[question_index]["answer"]
        if selected_answer == correct_answer:
            score += 1
        question_index += 1
        if question_index < total_questions:
            return redirect(url_for('ask_question', level=level, question_index=question_index, score=score))
        else:
            return render_template('quiz_result.html', score=score, total_questions=total_questions)
    
    question_index = 0
    return redirect(url_for('ask_question', level=level, question_index=question_index, score=score))

@app.route('/ask_question/<level>/<int:question_index>/<int:score>', methods=['GET', 'POST'])
def ask_question(level, question_index, score):
    quiz_data = quizzes.get(level, [])
    question = quiz_data[question_index]
    if request.method == 'POST':
        selected_answer = request.form.get('answer')
        correct_answer = question["answer"]
        if selected_answer == correct_answer:
            score += 1
        question_index += 1
        if question_index < len(quiz_data):
            return render_template('ask_question.html', question=quiz_data[question_index], level=level,
                                   question_index=question_index, score=score)
        else:
            return render_template('quiz_result.html', score=score, total_questions=len(quiz_data))
    return render_template('ask_question.html', question=question, level=level,
                           question_index=question_index, score=score)


@app.route('/quiz_result')
def quiz_result():
    return render_template('quiz_result.html')

if __name__ == '__main__':
    app.run(debug=True)

